#include "StdAfx.h"
#include "Vector.h"
#define MAX 30

Vector::Vector(void)
{tamano=0;
vec[MAX]=0;
}
double Vector::Get_tamano()
{
	return tamano;
}
void Vector::Set_tamano(double tam)
{
	tamano=tam;
}
double Vector::Get_vector(int posicion)
{
	return vec[posicion];
}
void Vector::Set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Vector::LlenoVector()
{
	if(tamano==MAX-1)
	{return true;}
	else{return false;}
}
bool Vector::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Vector::Ingresar(int posicion, double elemento)
{
	if((posicion<0)||(posicion>tamano))
	{return false;}
	else
		{
			if(LlenoVector()==true)
			{return false;}
			else
				{
					int i=Get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}

		}
}
double Vector::Promedio(int pos)
{double promedio;
promedio=(vec[pos]+vec[pos+1]+vec[pos+2])/3;
return promedio;
}
