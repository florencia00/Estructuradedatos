#pragma once
class NODO
{
protected:


public:
	NODO(void);
};

