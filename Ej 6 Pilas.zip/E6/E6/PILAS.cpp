#include "StdAfx.h"
#include "PILAS.h"


PILAS::PILAS(void)
{
	puntero=-1;
	P[M]=0;
}
void PILAS::Apilar(int x){
	P[++puntero]=x;
}
int PILAS::Desapilar(){
	int a=P[puntero--];
	return a;
}
bool PILAS::Vacio(){
	if(puntero==-1)
		return true;
}
bool PILAS::Lleno(){
	if(puntero==M-1)
		return true;
}
int PILAS::Getpuntero(){
	return puntero;
}
