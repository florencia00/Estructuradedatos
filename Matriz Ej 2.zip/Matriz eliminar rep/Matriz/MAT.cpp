#include "StdAfx.h"
#include "MAT.h"


MAT::MAT(void)
{
	filas=0;
	columnas=0;
	Matriz[M][M]=0;
}
int MAT::GetFilas(){
return filas;}
void MAT::SetFilas(int F){
filas=F;}
int MAT::GetColumnas(){
return columnas;}
void MAT::SetColumnas(int C){
columnas=C;}
int MAT::GetMatriz(int CF, int CC){
return Matriz[CF][CC];}
void MAT::SetMatriz(int CF, int CC, int a){
Matriz[CF][CC]=a;
}

int MAT::ContMatSup(){
	int fil=0, col=0;
	int aux2=0;
	int cont2=0;
	do{
		int aux=GetMatriz(fil,col);
		int k=0;
		for(int i=fil+1;i<GetFilas()-1;i++)
			{
				aux2=GetMatriz(i,col);
				if(aux2!=0)
				{k=1;}
			}
		if(k==0)
			{
				col++;
				fil=col;
			}
		cont2=k;
	}while(col!=GetFilas());
	return cont2;
}
