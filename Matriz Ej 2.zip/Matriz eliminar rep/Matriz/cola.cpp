#include "StdAfx.h"
#include "cola.h"
#include "string"

using namespace std;
cola::cola(void)
{
	frente=0;
	fin=-1;
}
/*void cola::encolar(string a){
++fin;
col[fin]=a;}
string cola::desencolar(){
string valor=col[frente++];
return valor;}
bool cola::lleno(){
	if(fin==L-1)
		return true;
}
bool cola::vacio(){
if(fin==-1)
return true;
}*/