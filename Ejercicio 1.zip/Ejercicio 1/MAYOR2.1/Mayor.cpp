#include "StdAfx.h"
#include "Mayor.h"
#define M 20


Mayor::Mayor(void)
{
	vec[M]=0;
	tamano=0;
}

double Mayor::Get_tamano()
{
	return tamano;
}
void Mayor::Set_tamano(double tam)
{
	tamano=tam;
}
double Mayor::Get_vector(int posicion)
{
	return vec[posicion];
}
void Mayor::Set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Mayor::LlenoVector()
{
	if(tamano==M-1)
	{return true;}
	else{return false;}
}
bool Mayor::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Mayor::Ingresar(int posicion, double elemento)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;}
	else
		{
			if(LlenoVector()==true)
			{return false;}
			else
				{
					int i=Get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}

		}
}
double Mayor::BuscarMayor()
{
	double may=vec[0];
	for( int i=0;i<tamano;i++)
	{
		if(vec[i]>may)
		{
			may=vec[i];
		}
	}
	return may;
}


