#pragma once
# define M 20
class Mayor
{
private:
	int tamano;
	double vec[M];
public:
	Mayor(void);
	double Get_tamano();
	void Set_tamano(double tam);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	bool LlenoVector();
	bool VacioVector();
	bool Ingresar(int posicion, double elemento);
	double BuscarMayor();
};

