#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
}
string NODO::GetNom(){
return Nombre;}
void NODO::SetNom(string N){
Nombre=N;}
int NODO::GetId(){
return Id;}
void NODO::SetId(int I){
Id=I;}