#pragma once
#include <string>
#include "NODO.h"
#include "PILA.h"
#include "msclr\marshal_cppstd.h"

namespace Ejercicio {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	NODO N1;
	PILA P1;
	int pos=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::TextBox^  txtNom;
	private: System::Windows::Forms::TextBox^  txtId;
	private: System::Windows::Forms::TextBox^  IdEl;
	private: System::Windows::Forms::TextBox^  NomEl;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->txtNom = (gcnew System::Windows::Forms::TextBox());
			this->txtId = (gcnew System::Windows::Forms::TextBox());
			this->IdEl = (gcnew System::Windows::Forms::TextBox());
			this->NomEl = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(317, 21);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 10;
			this->button1->Text = L"Desapilar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, this->Column2});
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(13, 60);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(254, 150);
			this->Grid->TabIndex = 9;
			this->Grid->RowCount = 25;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Nombre";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Id";
			this->Column2->Name = L"Column2";
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(236, 21);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(75, 23);
			this->btnApilar->TabIndex = 8;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// txtNom
			// 
			this->txtNom->Location = System::Drawing::Point(24, 21);
			this->txtNom->Name = L"txtNom";
			this->txtNom->Size = System::Drawing::Size(100, 20);
			this->txtNom->TabIndex = 7;
			// 
			// txtId
			// 
			this->txtId->Location = System::Drawing::Point(130, 21);
			this->txtId->Name = L"txtId";
			this->txtId->Size = System::Drawing::Size(100, 20);
			this->txtId->TabIndex = 11;
			// 
			// IdEl
			// 
			this->IdEl->Location = System::Drawing::Point(130, 229);
			this->IdEl->Name = L"IdEl";
			this->IdEl->Size = System::Drawing::Size(100, 20);
			this->IdEl->TabIndex = 13;
			// 
			// NomEl
			// 
			this->NomEl->Location = System::Drawing::Point(24, 229);
			this->NomEl->Name = L"NomEl";
			this->NomEl->Size = System::Drawing::Size(100, 20);
			this->NomEl->TabIndex = 12;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(415, 261);
			this->Controls->Add(this->IdEl);
			this->Controls->Add(this->NomEl);
			this->Controls->Add(this->txtId);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtNom);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
				 string N=marshal_as<std::string>(Convert::ToString(txtNom->Text));
				 int Id=Convert::ToInt32(txtId->Text);
				 N1.SetNom(N);
				 N1.SetId(Id);
				 P1.Apilar(N1);
				 Grid->Rows[pos]->Cells[0]->Value=marshal_as<System::String^>(N);
				 Grid->Rows[pos]->Cells[1]->Value=Id;
				 pos++;
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(P1.Vacio()==false)
			 {
			 N1=P1.Desapilar();
			 NomEl->Text=marshal_as<System::String^>(N1.GetNom());
			 IdEl->Text=Convert::ToString(N1.GetId());
			 Grid->Rows->RemoveAt(--pos);
			 }
			 else
			 { MessageBox::Show("Nope");}

		 }
};
}

