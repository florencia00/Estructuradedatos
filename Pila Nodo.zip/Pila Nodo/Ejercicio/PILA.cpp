#include "StdAfx.h"
#include "PILA.h"


PILA::PILA(void)
{
	cima=-1;
}
void PILA::Apilar(NODO elem)
{
	P[++cima]=elem;
}
NODO PILA::Desapilar()
{ NODO aux;
aux=P[cima--];
return aux;
}
bool PILA::Vacio(){
if(cima==-1)
return true;
}
bool PILA::Lleno(){
if(cima==M-1)
return true;
}