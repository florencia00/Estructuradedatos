#pragma once
#include "NODO.h"
#define M 25
class PILA:public NODO
{
private:
	NODO P[M];
	int cima;
public:
	PILA(void);
	void Apilar(NODO elem);
	NODO Desapilar();
	bool Vacio();
	bool Lleno();

};

