#include "StdAfx.h"
#include "MAT.h"



MAT::MAT(void)
{
	filas=0;
	columnas=0;
}
int MAT::GetFilas(){
return filas;}
void MAT::SetFilas(int F){
filas=F;}
int MAT::GetColumnas(){
return columnas;}
void MAT::SetColumnas(int C){
columnas=C;}
string MAT::GetMatriz(int CF, int CC){
return Matriz[CF][CC];}
void MAT::SetMatriz(int CF, int CC, string a){
Matriz[CF][CC]=a;
}

void MAT::EliminarRep(){
int F=0,C=0;
string P;
do
{
	do{
	int k=0;
	string aux=Matriz[F][C];
	for(int i=0;i<GetFilas();i++)
	{
		for(int j=0;j<GetColumnas();j++)
		{
			P=Matriz[i][j];
			if(P==aux)
			{k++;
			if(k>1)
			{SetMatriz(i,j," ");}
			}
		}
	}
	C++;}while(C<GetColumnas());
	F++;
	C=0;
	}while (F<GetFilas()&&C<GetColumnas());

}