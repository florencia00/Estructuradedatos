#pragma once
#define L 50
#include "string"

using namespace std;
class cola
{
private:
	int frente;
	int fin;
	//string col[L];

public:
	cola(void);
	void encolar(string a);
	string desencolar();
	bool lleno();
	bool vacio();
};

