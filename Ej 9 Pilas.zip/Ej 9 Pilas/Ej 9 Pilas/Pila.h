#pragma once
#define M 25
class Pila
{
private:
	int P[M];
	int tope;
public:
	Pila(void);
	void Apilar(int x);
	int Desapilar();
	bool Lleno();
	bool Vacio();

};

