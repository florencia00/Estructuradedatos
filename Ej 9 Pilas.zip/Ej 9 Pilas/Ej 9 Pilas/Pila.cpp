#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	tope= -1;
	P[M]=0;
}

void Pila::Apilar(int x)
{
	P[++tope]=x;
}
int Pila::Desapilar()
{
	int x=P[tope--];
	return x;
}
bool Pila::Lleno()
{
	if(tope==M-1)
		return true;
}
bool Pila::Vacio()
{
	if(tope==-1)
		return true;
}
