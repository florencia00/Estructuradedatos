#pragma once
#define M 60
class MAT
{
private:
	int Matriz[M][M];
	int filas;
	int columnas;

public:
	MAT(void);
	int Get_Filas();
	void Set_Filas(int F);
	int Get_Columnas();
	void Set_Columnas(int C);
	int Get_Matriz(int F, int C);
	void Set_Matriz(int F, int C, int elemento);
	MAT Sumar(MAT M1,MAT M2);
	MAT Restar(MAT M1,MAT M2);
	MAT Multiplicar(MAT M1,MAT M2);
};

