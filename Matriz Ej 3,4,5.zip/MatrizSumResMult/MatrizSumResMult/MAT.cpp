#include "StdAfx.h"
#include "MAT.h"


MAT::MAT(void)
{
	Matriz[M][M]=0;
	filas=0;
	columnas=0;
}
int MAT::Get_Filas(){
	return filas;
}
void MAT::Set_Filas(int F){
	filas=F;
}
int MAT::Get_Columnas(){
	return columnas;
}
void MAT::Set_Columnas(int C){
	columnas=C;
}
int MAT::Get_Matriz(int F, int C){
	return Matriz[F][C];
}
void MAT::Set_Matriz(int F, int C, int elemento){
	Matriz[F][C]=elemento;
}
MAT MAT::Sumar(MAT M1,MAT M2){
MAT M3;
for(int i=0;i<M1.Get_Filas();i++)
{
	for(int j=0;j<M1.Get_Columnas();j++)
	{
		int a=M1.Get_Matriz(i,j)+M2.Get_Matriz(i,j);
		M3.Set_Matriz(i,j,a);
	}
}
return M3;}
MAT MAT::Restar(MAT M1,MAT M2){
MAT M3;
for(int i=0;i<M1.Get_Filas();i++)
{
	for(int j=0;j<M1.Get_Columnas();j++)
	{
		int a=M1.Get_Matriz(i,j)-M2.Get_Matriz(i,j);
		M3.Set_Matriz(i,j,a);
	}
}
return M3;}
MAT MAT::Multiplicar(MAT M1,MAT M2){
MAT M3;
M3.Set_Filas(M1.Get_Filas());
M3.Set_Columnas(M2.Get_Columnas());
for(int i=0;i<M1.Get_Filas();i++)
{
	for(int j=0;j<M2.Get_Columnas();j++)
	{int a=0;
		for(int z=0;z<M1.Get_Columnas();z++)
			{
			
			a=a+M1.Get_Matriz(i,z)*M2.Get_Matriz(z,j);
			}
		M3.Set_Matriz(i,j,a);
		}
	}
return M3;}
