#pragma once
#include "MAT.h"

namespace MatrizSumResMult {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	MAT M1;
	MAT M2;
	MAT M3;
	int posf=0;int posf2=0;int posf3=0;
	int posc=0;int posc2=0;int posc3=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Button^  btnIng;
	private: System::Windows::Forms::TextBox^  txtDato;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::Button^  txtDefinir;
	private: System::Windows::Forms::TextBox^  txtColumnas;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtFilas;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  txtDato2;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  txtColumnas2;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtFilas2;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::DataGridView^  Grid3;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::DataGridView^  Grid4;
	private: System::Windows::Forms::DataGridView^  Grid5;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnIng = (gcnew System::Windows::Forms::Button());
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->txtDefinir = (gcnew System::Windows::Forms::Button());
			this->txtColumnas = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtFilas = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txtDato2 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->txtColumnas2 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtFilas2 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->Grid3 = (gcnew System::Windows::Forms::DataGridView());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->Grid4 = (gcnew System::Windows::Forms::DataGridView());
			this->Grid5 = (gcnew System::Windows::Forms::DataGridView());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid5))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(74, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(44, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Matriz 1";
			// 
			// btnIng
			// 
			this->btnIng->Location = System::Drawing::Point(181, 99);
			this->btnIng->Name = L"btnIng";
			this->btnIng->Size = System::Drawing::Size(75, 23);
			this->btnIng->TabIndex = 17;
			this->btnIng->Text = L"Ingresar";
			this->btnIng->UseVisualStyleBackColor = true;
			this->btnIng->Click += gcnew System::EventHandler(this, &Form1::btnIng_Click);
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(75, 101);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(100, 20);
			this->txtDato->TabIndex = 16;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(23, 104);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(30, 13);
			this->label3->TabIndex = 15;
			this->label3->Text = L"Dato";
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(26, 133);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(220, 146);
			this->Grid->TabIndex = 14;
			// 
			// txtDefinir
			// 
			this->txtDefinir->Location = System::Drawing::Point(181, 37);
			this->txtDefinir->Name = L"txtDefinir";
			this->txtDefinir->Size = System::Drawing::Size(75, 39);
			this->txtDefinir->TabIndex = 13;
			this->txtDefinir->Text = L"Definir ";
			this->txtDefinir->UseVisualStyleBackColor = true;
			this->txtDefinir->Click += gcnew System::EventHandler(this, &Form1::txtDefinir_Click);
			// 
			// txtColumnas
			// 
			this->txtColumnas->Location = System::Drawing::Point(75, 60);
			this->txtColumnas->Name = L"txtColumnas";
			this->txtColumnas->Size = System::Drawing::Size(100, 20);
			this->txtColumnas->TabIndex = 12;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(23, 63);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 11;
			this->label2->Text = L"Columnas";
			// 
			// txtFilas
			// 
			this->txtFilas->Location = System::Drawing::Point(75, 34);
			this->txtFilas->Name = L"txtFilas";
			this->txtFilas->Size = System::Drawing::Size(100, 20);
			this->txtFilas->TabIndex = 10;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(23, 37);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(28, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Filas";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(471, 99);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 26;
			this->button1->Text = L"Ingresar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txtDato2
			// 
			this->txtDato2->Location = System::Drawing::Point(365, 101);
			this->txtDato2->Name = L"txtDato2";
			this->txtDato2->Size = System::Drawing::Size(100, 20);
			this->txtDato2->TabIndex = 25;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(313, 104);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(30, 13);
			this->label5->TabIndex = 24;
			this->label5->Text = L"Dato";
			// 
			// Grid2
			// 
			this->Grid2->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid2->Location = System::Drawing::Point(316, 133);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(220, 146);
			this->Grid2->TabIndex = 23;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(471, 37);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 39);
			this->button2->TabIndex = 22;
			this->button2->Text = L"Definir ";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// txtColumnas2
			// 
			this->txtColumnas2->Location = System::Drawing::Point(365, 60);
			this->txtColumnas2->Name = L"txtColumnas2";
			this->txtColumnas2->Size = System::Drawing::Size(100, 20);
			this->txtColumnas2->TabIndex = 21;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(313, 63);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(53, 13);
			this->label6->TabIndex = 20;
			this->label6->Text = L"Columnas";
			// 
			// txtFilas2
			// 
			this->txtFilas2->Location = System::Drawing::Point(365, 34);
			this->txtFilas2->Name = L"txtFilas2";
			this->txtFilas2->Size = System::Drawing::Size(100, 20);
			this->txtFilas2->TabIndex = 19;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(313, 37);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(28, 13);
			this->label7->TabIndex = 18;
			this->label7->Text = L"Filas";
			// 
			// Grid3
			// 
			this->Grid3->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid3->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid3->Location = System::Drawing::Point(626, 41);
			this->Grid3->Name = L"Grid3";
			this->Grid3->Size = System::Drawing::Size(220, 146);
			this->Grid3->TabIndex = 27;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(696, 12);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 28;
			this->button3->Text = L"Sumar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(936, 9);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 29;
			this->button4->Text = L"Restar";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(823, 205);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 23);
			this->button5->TabIndex = 30;
			this->button5->Text = L"Multiplicar";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// Grid4
			// 
			this->Grid4->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid4->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid4->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid4->Location = System::Drawing::Point(870, 41);
			this->Grid4->Name = L"Grid4";
			this->Grid4->Size = System::Drawing::Size(220, 146);
			this->Grid4->TabIndex = 31;
			// 
			// Grid5
			// 
			this->Grid5->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid5->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid5->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid5->Location = System::Drawing::Point(751, 234);
			this->Grid5->Name = L"Grid5";
			this->Grid5->Size = System::Drawing::Size(220, 146);
			this->Grid5->TabIndex = 32;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1370, 431);
			this->Controls->Add(this->Grid5);
			this->Controls->Add(this->Grid4);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->Grid3);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtDato2);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->txtColumnas2);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtFilas2);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->btnIng);
			this->Controls->Add(this->txtDato);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtDefinir);
			this->Controls->Add(this->txtColumnas);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtFilas);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Grid5";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid5))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void txtDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int F=Convert::ToInt32(txtFilas->Text);
				 int C=Convert::ToInt32(txtColumnas->Text);
				 M1.Set_Filas(F);
				 M1.Set_Columnas(C);
				 Grid->RowCount=M1.Get_Filas();
				 Grid->ColumnCount=M1.Get_Columnas();
			 }
private: System::Void btnIng_Click(System::Object^  sender, System::EventArgs^  e) {

			 int a=Convert::ToInt32(txtDato->Text);
			 M1.Set_Matriz(posf,posc,a);
			 Grid->Rows[posf]->Cells[posc]->Value=M1.Get_Matriz(posf,posc);
			 if(posc==M1.Get_Columnas()-1)
			 {
				 posf++;
				 posc=0;
			 }
			 else
			 {
				 posc++;
			 }
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int F=Convert::ToInt32(txtFilas2->Text);
			 int C=Convert::ToInt32(txtColumnas2->Text);
			 M2.Set_Filas(F);
			 M2.Set_Columnas(C);
			 Grid2->RowCount=M2.Get_Filas();
			 Grid2->ColumnCount=M2.Get_Columnas();
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int a=Convert::ToInt32(txtDato2->Text);
			 M2.Set_Matriz(posf2,posc2,a);
			 Grid2->Rows[posf2]->Cells[posc2]->Value=M2.Get_Matriz(posf2,posc2);
			 if(posc2==M2.Get_Columnas()-1)
			 {
				 posf2++;
				 posc2=0;
			 }
			 else
			 {
				 posc2++;
			 }
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			if(M1.Get_Filas()!=M2.Get_Filas()&&M1.Get_Columnas()!=M2.Get_Columnas())
				MessageBox::Show("Las matrices no se pueden sumar");
				else
				 {MAT M4;
				 Grid3->RowCount=M1.Get_Filas();
				 Grid3->ColumnCount=M1.Get_Columnas();
				 M4=M3.Sumar(M1,M2);
				 for(int i=0;i<M1.Get_Filas();i++)
					{
						for(int j=0;j<M1.Get_Columnas();j++)
						{
							Grid3->Rows[i]->Cells[j]->Value=M4.Get_Matriz(i,j);
						}
					}
				 }
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 	if(M1.Get_Filas()!=M2.Get_Filas()&&M1.Get_Columnas()!=M2.Get_Columnas())
				MessageBox::Show("Las matrices no se pueden restar");
				else
				 {MAT M4;
				 Grid4->RowCount=M1.Get_Filas();
				 Grid4->ColumnCount=M1.Get_Columnas();
				 M4=M3.Restar(M1,M2);
				 for(int i=0;i<M1.Get_Filas();i++)
					{
						for(int j=0;j<M1.Get_Columnas();j++)
						{
							Grid4->Rows[i]->Cells[j]->Value=M4.Get_Matriz(i,j);
						}
					}
				 }
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			if(M2.Get_Filas()!=M1.Get_Columnas())
				MessageBox::Show("Las matrices no se pueden multiplicar");
				else
				 {MAT M4;
				 Grid5->RowCount=M1.Get_Filas();
				 Grid5->ColumnCount=M2.Get_Columnas();
				 M4=M3.Multiplicar(M1,M2);
				 for(int i=0;i<M4.Get_Filas();i++)
					{
						for(int j=0;j<M4.Get_Columnas();j++)
						{
							Grid5->Rows[i]->Cells[j]->Value=M4.Get_Matriz(i,j);
						}
					}
				 }
		 }
};
}

