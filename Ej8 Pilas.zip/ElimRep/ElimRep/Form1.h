#pragma once
#include "PILA.h"

namespace ElimRep {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	PILA P1;
	PILA P2;
	int pos=0;
	int pos2=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtDato;
	private: System::Windows::Forms::Button^  btnApil;
	private: System::Windows::Forms::Button^  btnDesapilar;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridView^  Grid;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Pila;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;
	private: System::Windows::Forms::Button^  button2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnApil = (gcnew System::Windows::Forms::Button());
			this->btnDesapilar = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Pila = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button2 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(23, 24);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(35, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Datos";
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(64, 21);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(100, 20);
			this->txtDato->TabIndex = 1;
			// 
			// btnApil
			// 
			this->btnApil->Location = System::Drawing::Point(170, 19);
			this->btnApil->Name = L"btnApil";
			this->btnApil->Size = System::Drawing::Size(75, 23);
			this->btnApil->TabIndex = 2;
			this->btnApil->Text = L"Apilar";
			this->btnApil->UseVisualStyleBackColor = true;
			this->btnApil->Click += gcnew System::EventHandler(this, &Form1::btnApil_Click);
			// 
			// btnDesapilar
			// 
			this->btnDesapilar->Location = System::Drawing::Point(170, 61);
			this->btnDesapilar->Name = L"btnDesapilar";
			this->btnDesapilar->Size = System::Drawing::Size(75, 23);
			this->btnDesapilar->TabIndex = 3;
			this->btnDesapilar->Text = L"Desapilar";
			this->btnDesapilar->UseVisualStyleBackColor = true;
			this->btnDesapilar->Click += gcnew System::EventHandler(this, &Form1::btnDesapilar_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(170, 104);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 41);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Eliminar Pares";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Pila});
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(12, 61);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(142, 188);
			this->Grid->TabIndex = 5;
			this->Grid->RowCount = 50;
			// 
			// Pila
			// 
			this->Pila->HeaderText = L"Pila";
			this->Pila->Name = L"Pila";
			// 
			// Grid2
			// 
			this->Grid2->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn1});
			this->Grid2->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid2->Location = System::Drawing::Point(271, 61);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(142, 188);
			this->Grid2->TabIndex = 6;
			this->Grid2->RowCount = 50;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Pila";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(170, 161);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 41);
			this->button2->TabIndex = 7;
			this->button2->Text = L"Eliminar Repetidos";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(437, 261);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnDesapilar);
			this->Controls->Add(this->btnApil);
			this->Controls->Add(this->txtDato);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApil_Click(System::Object^  sender, System::EventArgs^  e) {
				 int elem=Convert::ToInt32(txtDato->Text);
				 P1.Apilar(elem);
				 Grid->Rows[pos++]->Cells[0]->Value=elem;
			 }
private: System::Void btnDesapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 P1.Desapilar();
			 Grid->Rows->RemoveAt(--pos);
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			int aux;
			while(P1.Vacio()==false)
			{
				aux=P1.Desapilar();
				if(aux%2!=0)
					P2.Apilar(aux);
			}
			int aux2;
			while(P2.Vacio()==false)
			{
				int p=P2.Desapilar();
				Grid2->Rows[pos2++]->Cells[0]->Value=p;
			}
					}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 /*PILA P3;
			 int aux;
			 while(P1.Vacio()==false)
			 {	
				 aux=P1.Desapilar();
				 while(P1.Vacio()==false)
				 {
					int aux2=P1.Desapilar();
					if(aux2!=aux)
						P2.Apilar(aux2);
				 }
				 P3.Apilar(aux);
				 int a;
				 while(P2.Vacio()==false)
				 {
					 a=P2.Desapilar();
					 P1.Apilar(a);
				 }
			 }

			 while(P3.Vacio()==false)
			{
				int p=P3.Desapilar();
				Grid2->Rows[pos2++]->Cells[0]->Value=p;
			}*/
			 	Pila aux;				int aux1;				for (int i = 0; i <= top; i++) {					aux1 = Peek();					for (int j = 0; j <= top; j++) {						if (aux1 != Desapilar()) {							aux.Apilar(aux1);						}		}	}

		 }
};
}

