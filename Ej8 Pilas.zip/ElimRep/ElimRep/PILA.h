#pragma once
#define N 50
class PILA
{
private:
	int tope;
	int P[N];
public:
	PILA(void);
	int Get_Tope();
	void Apilar(int elem);
	int Desapilar();
	bool Lleno();
	bool Vacio();


};

