#pragma once
#define n 600
class Promedio
{private:
	double Vector[n];
	int tamanio;
public:
	Promedio(void);
	 ~Promedio(void);
	void Set_tamanio(int tam);
    int Get_tamanio();
	void Set_Vector(double vec,int pos);
	double Get_Vector(int pos);
	double PromedioVector(int pos);
};

