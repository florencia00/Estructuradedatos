#include "StdAfx.h"
#include "Promedio.h"


Promedio::Promedio(void)
{Vector[n]=0;
tamanio=0;
}
Promedio:: ~Promedio(void)
 {
 }
void Promedio::Set_tamanio(int tam)
{tamanio=tam;
 }
int Promedio::Get_tamanio()
{return tamanio;
 }
void Promedio::Set_Vector(double vec,int pos)
{Vector[pos]=vec;
 }
double Promedio::Get_Vector(int pos)
{return Vector[pos];
 }
double Promedio::PromedioVector(int pos)
{double s=0;
for(int k=0;k<=pos;k++)
{s=s+Vector[k];
}
s=s/pos;
return s;
 }