#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{
	puntero = NULL;
}


Nodo::~Nodo(void)
{
}
