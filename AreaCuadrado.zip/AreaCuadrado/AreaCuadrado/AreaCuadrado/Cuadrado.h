#pragma once


class Cuadrado
{
private:
	int lado;
	int area;

public:
	Cuadrado(void);
	int Get_lado();
	void Set_lado(int l);
	int Get_area();
	void Set_area(int a);
	int Calcular();
};

