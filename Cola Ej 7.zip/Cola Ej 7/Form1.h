#pragma once
#include "Cola.h"

namespace CppCLRWinformsProjekt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Zusammenfassung f�r Form1
	/// </summary>
	Cola C1;
	Cola C2;
	int pos=0;
	int pos2 = 0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ txtDato;
	protected:
	private: System::Windows::Forms::Button^ btnEncolar;
	private: System::Windows::Forms::DataGridView^ Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column1;
	private: System::Windows::Forms::Button^ btnDes;
	private: System::Windows::Forms::Button^ btnOrd;



	protected:

	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnEncolar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnDes = (gcnew System::Windows::Forms::Button());
			this->btnOrd = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(40, 30);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(100, 20);
			this->txtDato->TabIndex = 0;
			// 
			// btnEncolar
			// 
			this->btnEncolar->Location = System::Drawing::Point(171, 30);
			this->btnEncolar->Name = L"btnEncolar";
			this->btnEncolar->Size = System::Drawing::Size(75, 23);
			this->btnEncolar->TabIndex = 1;
			this->btnEncolar->Text = L"Encolar";
			this->btnEncolar->UseVisualStyleBackColor = true;
			this->btnEncolar->Click += gcnew System::EventHandler(this, &Form1::btnEncolar_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->Column1 });
			this->Grid->Location = System::Drawing::Point(12, 76);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(135, 150);
			this->Grid->TabIndex = 2;
			this->Grid->RowCount = 25;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Cola";
			this->Column1->Name = L"Column1";
			// 
			// btnDes
			// 
			this->btnDes->Location = System::Drawing::Point(171, 94);
			this->btnDes->Name = L"btnDes";
			this->btnDes->Size = System::Drawing::Size(75, 23);
			this->btnDes->TabIndex = 3;
			this->btnDes->Text = L"Desencolar";
			this->btnDes->UseVisualStyleBackColor = true;
			this->btnDes->Click += gcnew System::EventHandler(this, &Form1::btnDes_Click);
			// 
			// btnOrd
			// 
			this->btnOrd->Location = System::Drawing::Point(171, 154);
			this->btnOrd->Name = L"btnOrd";
			this->btnOrd->Size = System::Drawing::Size(75, 23);
			this->btnOrd->TabIndex = 4;
			this->btnOrd->Text = L"Ordenar";
			this->btnOrd->UseVisualStyleBackColor = true;
			this->btnOrd->Click += gcnew System::EventHandler(this, &Form1::btnOrd_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(273, 261);
			this->Controls->Add(this->btnOrd);
			this->Controls->Add(this->btnDes);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnEncolar);
			this->Controls->Add(this->txtDato);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnEncolar_Click(System::Object^ sender, System::EventArgs^ e) {
		if (C1.lleno())
			MessageBox::Show("Cola llena");
		else {
			int elem = Convert::ToInt32(txtDato->Text);
			C1.encolar(elem);
			Grid->Rows[pos++]->Cells[0]->Value = elem;
		}
	}
	private: System::Void btnDes_Click(System::Object^ sender, System::EventArgs^ e) {
		if (C1.vacio())
			MessageBox::Show("Cola vacia");
		else {
			int a=C1.desencolar();
			Grid->Rows->RemoveAt(0);
			
		}
	}
private: System::Void btnOrd_Click(System::Object^ sender, System::EventArgs^ e) {
	int aux;
	do {
		aux = C1.desencolar();
		--pos;
		for (int i = 0; i < pos; i++)
		{
			int aux2 = C1.desencolar();
			if (aux2 < aux) {
				int auxa;
				auxa = aux;
				aux = aux2;
				C1.encolar(auxa);
			}
			else {
				C1.encolar(aux2);
			}
		}
		C2.encolar(aux);
		Grid->Rows[pos2++]->Cells[0]->Value = Convert::ToString(aux);
	} while (C1.vacio() != true);
}
};
}
