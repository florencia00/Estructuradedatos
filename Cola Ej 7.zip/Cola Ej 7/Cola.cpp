#include "pch.h"
#include "Cola.h"
Cola::Cola(void) {
	frente = 0;
	final = -1;
}
void Cola::encolar(int x) {
	C[++final] = x;
}
int Cola::desencolar() {
	int a = C[frente++];
	return a;
}
bool Cola::lleno() {
	if (final == M - 1)
		return true;
}
bool Cola::vacio() {
	if (frente > final)
		return true;
}

int Cola::Get_final() {
	return final;
}
int Cola::Get_Cola(int pos) {
	return C[pos];
}
