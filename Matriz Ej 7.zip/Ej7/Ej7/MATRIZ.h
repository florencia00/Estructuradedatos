#pragma once
#define N 50
#define M 5
class MATRIZ
{
private:
	int Filas;
	int Mat[N][M];
public:
	MATRIZ(void);
	int Get_Filas();
	int Get_Matriz(int F, int C);
	void Set_Filas(int F);
	void Set_Matriz(int F,int C, int a);
	/*MATRIZ Ventas(MATRIZ M1);
	int VentasTotal(MATRIZ M1);
	int SucursalMayVent(MATRIZ M2);
	int MesMenVent(MATRIZ M1);*/

};

