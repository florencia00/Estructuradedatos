#include "StdAfx.h"
#include "MATRIZ.h"


MATRIZ::MATRIZ(void)
{
	Filas=0;
	Mat[N][M]=0;
}
int MATRIZ::Get_Filas(){
return Filas;
}
int MATRIZ::Get_Matriz(int F,int C){
	return Mat[N][C];
}
void MATRIZ::Set_Filas(int F){
Filas=F;}
void MATRIZ::Set_Matriz(int F,int C, int a){
Mat[F][C]=a;}

/*MATRIZ MATRIZ::Ventas(MATRIZ M1){
MATRIZ M2;
M2.Set_Filas(M1.Get_Filas());
for (int f=0;f<M1.Get_Filas();f++)
{
	int aux=0;
	int pos=0;
	for(int i=0;i<5;i++)
	{
		aux=aux+M1.Get_Matriz(f,i);
	}
	M2.Set_Matriz(pos,0,aux);
	pos++;
}
return M2;
}
int MATRIZ::VentasTotal(MATRIZ M1){
int VT=0;
for(int i=0;i<M1.Get_Filas();i++)
{
	for(int j=0;j<5;j++)
	{
		VT=VT+M1.Get_Matriz(i,j);
	}
}
return VT;
}
int MATRIZ::SucursalMayVent(MATRIZ M2){
	int aux=M2.Get_Matriz(0,0);
	for(int i=0;i<M2.Get_Filas();i++)
{
	for(int j=0;j<5;j++)
	{
		int aux2=M2.Get_Matriz(i,j);
		if(aux2>aux)
			aux=aux2;
	}
	return aux;
}

}
int MATRIZ::MesMenVent(MATRIZ M1){
	MATRIZ M4;
	M4.Set_Filas(1);
	for(int i=0;i<5;i++)
	{
		int aux=0;
		for (int f=0;f<M1.Get_Filas();f++)
		{
			aux=aux+M1.Get_Matriz(f,i);
		}
		M4.Set_Matriz(0,i,aux);
	}
	int aux2=M4.Get_Matriz(0,0);
		for(int i=0;i<5;i++)
		{
			int aux=M4.Get_Matriz(0,i);
			if(aux>aux2)
				aux2=aux;
		}
		return aux2;
}
*/