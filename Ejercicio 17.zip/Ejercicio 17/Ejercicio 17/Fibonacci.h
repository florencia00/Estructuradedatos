#pragma once
#define M 100
class Fibonacci
{
private:
	int tamano;
	double vec[M];
public:
	Fibonacci(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_vector(int posicion);
	void Set_vector(int posicion,double elemento);
	bool LlenoVector();
	bool VacioVector();
	void Obtener(int tam);
};
