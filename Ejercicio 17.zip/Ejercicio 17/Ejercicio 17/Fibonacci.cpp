#include "StdAfx.h"
#include "Fibonacci.h"


Fibonacci::Fibonacci(void)
{
}
int Fibonacci::Get_tamano()
{
	return tamano;
}
void Fibonacci::Set_tamano(int tam)
{
	tamano=tam;
}
int Fibonacci::Get_vector(int posicion)
{
	return vec[posicion];
}
void Fibonacci::Set_vector(int posicion,double elemento)
{vec[posicion]=elemento;}

bool Fibonacci::LlenoVector()
{
	if(tamano==M-1)
	{return true;}
	else{return false;}
}
bool Fibonacci::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
void Fibonacci::Obtener(int tam)
{int a=0;
	int b=1;
	int c;
	vec[0]=a;
	vec[1]=b;
	for(int i=2;i<tam;i++)
	{c=a+b;
	vec[i]=c;
	a=b;b=c;
	}
}