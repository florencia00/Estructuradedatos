#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{
	Filas=0;
	Columnas=0;
	Mat[M][M]=0;
}
int Matriz::Get_Filas(){
return Filas;}
int Matriz::Get_Columnas(){
return Columnas;}
int Matriz::Get_Matriz(int F,int C){
return Mat[F][C];}
void Matriz::Set_Filas(int F){
Filas=F;}
void Matriz::Set_Columnas(int C){
Columnas=C;}
void Matriz::Set_Matriz(int F,int C, int x){
	Mat[F][C]=x;}
Matriz Matriz::Transpuesta(Matriz M1){
Matriz M2;
M2.Set_Filas(M1.Get_Columnas());
M2.Set_Columnas(M1.Get_Filas());
for (int i=0;i<M2.Get_Filas();i++)
{for (int k=0;k<M2.Get_Columnas();k++)
	{M2.Set_Matriz(i,k,M1.Get_Matriz(k,i));}
	}
return M2;
}
