#pragma once
#define M 50
class Matriz
{
private:
	int Filas;
	int Columnas;
	int Mat[M][M];
public:
	Matriz(void);
	int Get_Filas();
	int Get_Columnas();
	int Get_Matriz(int F,int C);
	void Set_Filas(int F);
	void Set_Columnas(int C);
	void Set_Matriz(int F,int C, int x);
	Matriz Transpuesta(Matriz M1);

};

