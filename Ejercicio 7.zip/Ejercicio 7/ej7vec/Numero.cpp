#include "StdAfx.h"
#include "Numero.h"
#include "iostream"
#include <string>

using namespace std;

Numero::Numero(void)
{
}
int Numero::Get_Tamano()
{
	return Tamano;
}
void Numero::Set_Tamano(int x)
{
	Tamano= x;
}
int Numero::Get_vector(int y)
{
	return vector[y];
}

void Numero::Set_vector(int x, int y)
{
	vector[y]= x;
}

string Numero::agregar(int x)
{
	if(x>=0 && x<=20)
	{
	 switch(x)
	 {
	  case 0:
		return "cero";
		break;
	  case 1:
		return "uno";
		break;
	  case 2:
	    return "dos";
		break;
	  case 3:
		return "tres";
		break;
	  case 4:
		return "cuatro";
		break;
	  case 5:
		return "cinco";
		break;
	  case 6:
		return "seis";
		break;
	  case 7:
		return "siete";
		break;
	  case 8:
		return "ocho";
		break;
      case 9:
		return "nueve";
		break;
	  case 10:
		return "diez";
		break;
	  case 11:
		return "once";
		break;
	  case 12:
		return "doce";
		break;
	 case 13:
		return "trece";
		break;
	  case 14:
		return "catorce";
		break;
	  case 15:
		return "quince";
		break;
	  case 16:
		return "diesciseis";
		break;
	  case 17:
		return "diecisiete";
		break;
	  case 18:
		return "dieciocho";
		break;
      case 19:
		return "diecinueve";
		break;
	  case 20:
		return "veinte";
	
		break;
	 }}}
