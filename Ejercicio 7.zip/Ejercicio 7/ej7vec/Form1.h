#pragma once
#include "Numero.h"
#include <iostream>
#include <string>


namespace ej7vec {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std; 
	using namespace msclr::interop;

	Numero numeros;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::Button^  btnTamano;
	private: System::Windows::Forms::Button^  btnAgregar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtLiteral;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->btnTamano = (gcnew System::Windows::Forms::Button());
			this->btnAgregar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtLiteral = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(26, 24);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(26, 70);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numero";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(78, 17);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(100, 20);
			this->txtTamano->TabIndex = 2;
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(78, 63);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(100, 20);
			this->txtNumero->TabIndex = 3;
			// 
			// btnTamano
			// 
			this->btnTamano->Location = System::Drawing::Point(205, 14);
			this->btnTamano->Name = L"btnTamano";
			this->btnTamano->Size = System::Drawing::Size(75, 23);
			this->btnTamano->TabIndex = 4;
			this->btnTamano->Text = L"Definir";
			this->btnTamano->UseVisualStyleBackColor = true;
			this->btnTamano->Click += gcnew System::EventHandler(this, &Form1::btnTamano_Click);
			// 
			// btnAgregar
			// 
			this->btnAgregar->Location = System::Drawing::Point(205, 60);
			this->btnAgregar->Name = L"btnAgregar";
			this->btnAgregar->Size = System::Drawing::Size(75, 23);
			this->btnAgregar->TabIndex = 5;
			this->btnAgregar->Text = L"Agregar";
			this->btnAgregar->UseVisualStyleBackColor = true;
			this->btnAgregar->Click += gcnew System::EventHandler(this, &Form1::btnAgregar_Click);
			// 
			// Grid
			// 
			this->Grid->AllowUserToOrderColumns = true;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(29, 99);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numeros";
			this->Column1->Name = L"Column1";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(35, 268);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(35, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Literal";
			// 
			// txtLiteral
			// 
			this->txtLiteral->Location = System::Drawing::Point(78, 268);
			this->txtLiteral->Name = L"txtLiteral";
			this->txtLiteral->Size = System::Drawing::Size(100, 20);
			this->txtLiteral->TabIndex = 8;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(482, 316);
			this->Controls->Add(this->txtLiteral);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnAgregar);
			this->Controls->Add(this->btnTamano);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTamano_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam= System::Convert::ToInt32(txtTamano->Text);
				 Grid->RowCount=tam;
			 }
	 private: System::Void btnAgregar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int numero;
			 string lit;
			 numero= System::Convert::ToInt32(txtNumero->Text);
			 numeros.Set_vector(numero,pos);
			 Grid->Rows[pos]->Cells[0]->Value= numero;
			  lit = numeros.agregar(numero);
			  txtLiteral->Text=marshal_as<System::String^>(lit);
			 pos++;
		 }

};
}

