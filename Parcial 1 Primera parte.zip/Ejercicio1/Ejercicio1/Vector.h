#pragma once
#define MAX 30
class Vector
{
private:
	int tamano;
	double vec[MAX];
public:
	Vector(void);
	double Get_tamano();
	void Set_tamano(double tam);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	bool LlenoVector();
	bool VacioVector();
	bool Ingresar(int posicion, double elemento);
	int Repetidos(int a);
};
