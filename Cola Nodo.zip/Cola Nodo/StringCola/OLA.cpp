#include "StdAfx.h"
#include "OLA.h"


COLA::COLA(void)
{
}
