#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	frente=0;
	final=-1;
}
void Cola::Encolar(NODO x){
	C[++final]=x;
}
NODO Cola::Desencolar(){
	NODO A=C[frente++];
	return A;
}
bool Cola::Lleno(){
	if(final==M-1)
		return true;
}
bool Cola::Vacio(){
	if(final<frente)
		return true;
}