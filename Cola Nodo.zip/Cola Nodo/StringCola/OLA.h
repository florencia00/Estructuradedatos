#pragma once
#include "NODO.h"

class COLA: public NODO
{
protected:

public:
	COLA(void);
};

