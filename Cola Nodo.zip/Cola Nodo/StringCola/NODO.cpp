#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
}
string NODO::GetNom(){
	return Nom;
}
void NODO::SetNom(string N){
	Nom=N;
}
int NODO::GetId(){
	return Id;
}
void NODO::SetId(int I){
	Id=I;
}
