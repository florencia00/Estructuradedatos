#pragma once
#include "NODO.h"
#define M 25
class Cola:public NODO
{
private:
	int frente;
	int final;
	NODO C[25];
public:
	Cola(void);
	void Encolar(NODO x);
	NODO Desencolar();
	bool Lleno();
	bool Vacio();
};

