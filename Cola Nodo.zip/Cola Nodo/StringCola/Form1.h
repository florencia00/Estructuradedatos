#pragma once
#include "string"
#include "NODO.h"
#include "Cola.h"
#include "msclr\marshal_cppstd.h"

namespace StringCola {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	NODO N1;
	Cola C1;
	int pos=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtId;
	protected: 
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  btnEnc;
	private: System::Windows::Forms::TextBox^  txtNom;
	private: System::Windows::Forms::TextBox^  IdEl;
	private: System::Windows::Forms::TextBox^  NomEl;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtId = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnEnc = (gcnew System::Windows::Forms::Button());
			this->txtNom = (gcnew System::Windows::Forms::TextBox());
			this->IdEl = (gcnew System::Windows::Forms::TextBox());
			this->NomEl = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// txtId
			// 
			this->txtId->Location = System::Drawing::Point(153, 36);
			this->txtId->Name = L"txtId";
			this->txtId->Size = System::Drawing::Size(100, 20);
			this->txtId->TabIndex = 16;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(340, 36);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 15;
			this->button1->Text = L"Desencolar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, this->Column2});
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(36, 75);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(254, 150);
			this->Grid->TabIndex = 14;
			this->Grid->RowCount=25;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Nombre";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Id";
			this->Column2->Name = L"Column2";
			// 
			// btnEnc
			// 
			this->btnEnc->Location = System::Drawing::Point(259, 36);
			this->btnEnc->Name = L"btnEnc";
			this->btnEnc->Size = System::Drawing::Size(75, 23);
			this->btnEnc->TabIndex = 13;
			this->btnEnc->Text = L"Encolar";
			this->btnEnc->UseVisualStyleBackColor = true;
			this->btnEnc->Click += gcnew System::EventHandler(this, &Form1::btnEnc_Click);
			// 
			// txtNom
			// 
			this->txtNom->Location = System::Drawing::Point(47, 36);
			this->txtNom->Name = L"txtNom";
			this->txtNom->Size = System::Drawing::Size(100, 20);
			this->txtNom->TabIndex = 12;
			// 
			// IdEl
			// 
			this->IdEl->Location = System::Drawing::Point(174, 231);
			this->IdEl->Name = L"IdEl";
			this->IdEl->Size = System::Drawing::Size(100, 20);
			this->IdEl->TabIndex = 18;
			// 
			// NomEl
			// 
			this->NomEl->Location = System::Drawing::Point(68, 231);
			this->NomEl->Name = L"NomEl";
			this->NomEl->Size = System::Drawing::Size(100, 20);
			this->NomEl->TabIndex = 17;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(451, 261);
			this->Controls->Add(this->IdEl);
			this->Controls->Add(this->NomEl);
			this->Controls->Add(this->txtId);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnEnc);
			this->Controls->Add(this->txtNom);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
		
#pragma endregion
	private: System::Void btnEnc_Click(System::Object^  sender, System::EventArgs^  e) {
				 string N=marshal_as<std::string>(Convert::ToString(txtNom->Text));
				 int Id=Convert::ToInt32(txtId->Text);
				 N1.SetNom(N);
				 N1.SetId(Id);
				 C1.Encolar(N1);
				 Grid->Rows[pos]->Cells[0]->Value=marshal_as<System::String^>(N);
				 Grid->Rows[pos]->Cells[1]->Value=Id;
				 pos++;
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 pos=0;
			 if(C1.Vacio()==false)
			 {
			  N1=C1.Desencolar();
			 NomEl->Text=marshal_as<System::String^>(N1.GetNom());
			 IdEl->Text=Convert::ToString(N1.GetId());
			 Grid->Rows->RemoveAt(pos);
			 }
			 else
			  MessageBox::Show("Nope");

		 }
};
}

