#pragma once
#include "string"
using namespace std;
class NODO
{
protected:
	string Nom;
	int Id;
public:
	NODO(void);
	string GetNom();
	void SetNom(string N);
	int GetId();
	void SetId(int I);
};

