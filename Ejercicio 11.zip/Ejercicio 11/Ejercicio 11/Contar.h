#pragma once
#define M 50

class Contar
{
private:
	double vec[M];
	int tamano;
public:
	Contar(void);
	int Get_tamano();
	void Set_tamano(int tam);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	bool LlenoVector();
	bool VacioVector();
	bool Llenar(int pos, double elemento);
	int ContarPosi(int tam);
	int ContarNeg(int tam);
	int ContarCero(int tam);

};

