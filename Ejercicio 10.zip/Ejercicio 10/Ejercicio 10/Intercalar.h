#pragma once
class Intercalar
{
public:
	Intercalar(void);
};
