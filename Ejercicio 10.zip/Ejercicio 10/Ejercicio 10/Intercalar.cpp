#include "Intercalar.h"


Intercalar::Intercalar(void)
{
}
