#include "StdAfx.h"
#include "Inter.h"


Inter::Inter(void)
{
}

int Inter::Get_tamano()
{
	return tamano;
}
void Inter::Set_tamano(int tam)
{
	tamano=tam;
}
double Inter::Get_vector(int posicion)
{
	return vec[posicion];
}
void Inter::Set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Inter::LlenoVector()
{
	if(tamano==M-1)
	{return true;}
	else{return false;}
}
bool Inter::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Inter::Llenar(int posicion, double elemento)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;}
	else
		{
			if(LlenoVector()==true)
			{return false;}
			else
				{
					int i=Get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}

		}
}
void Inter::Ordenar(int tam)
{
	int aux;
	for(int i=0;i<tam-1;i++)
	{for(int j=1;j<tam;j++)
	{if(vec[j]<vec[i])
	{aux=vec[i];
	vec[i]=vec[j];
	vec[j]=aux;}}}
}

	Inter Inter::Mezclar(Inter vec1,Inter vec2)
	{Inter vec3;
	vec3.Set_tamano(vec1.Get_tamano()+vec2.Get_tamano());
	for(int i=0;i<(vec1.Get_tamano()+vec1.Get_tamano());i++)
	{if(i%2==0)
		{for(int j=0;j<vec1.Get_tamano();j++)
			{vec3.vec[i]=vec1.Get_vector(j);}
		}
	
	else {if (i%2 != 0)
	{
		for(int k=0;k<vec2.Get_tamano();k++)
			{vec3.vec[i]=vec2.Get_vector(k);}
	}}}
	return vec3;
	}
	
