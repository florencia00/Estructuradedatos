#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	frente=0;
	final=-1;
}
void Cola::encolar(int elem){
	C[++final]=elem;
}
int Cola::desencolar(){
	int Des;
	Des=C[frente++];
	return Des;
}
bool Cola::lleno(){
	if(final==M-1)
		return true;
	else
		return false;
}
bool Cola::vacio(){
	if(frente>final)
		return true;
	else
		return false;
}
Cola Cola::ElimPares(Cola C1){
Cola C2;
do
{
	int elem=C1.desencolar();
	if(elem%2!=0)
		C2.encolar(elem);
}while (C1.vacio()==false);
return C2;
}
