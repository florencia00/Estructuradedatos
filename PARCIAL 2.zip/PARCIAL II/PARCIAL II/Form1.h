#pragma once
#include "Cola.h"

namespace PARCIALII {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	Cola C1;
	Cola C2;
	int pos=0;
	int pos2=0;
	int fren=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtDato;
	private: System::Windows::Forms::Button^  btnEncolar;
	private: System::Windows::Forms::Button^  btnDesencolar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btnElimPar;
	private: System::Windows::Forms::DataGridView^  Grilla2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnEncolar = (gcnew System::Windows::Forms::Button());
			this->btnDesencolar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnElimPar = (gcnew System::Windows::Forms::Button());
			this->Grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(27, 22);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(30, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Dato";
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(63, 22);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(100, 20);
			this->txtDato->TabIndex = 1;
			// 
			// btnEncolar
			// 
			this->btnEncolar->Location = System::Drawing::Point(169, 20);
			this->btnEncolar->Name = L"btnEncolar";
			this->btnEncolar->Size = System::Drawing::Size(75, 23);
			this->btnEncolar->TabIndex = 2;
			this->btnEncolar->Text = L"Encolar";
			this->btnEncolar->UseVisualStyleBackColor = true;
			this->btnEncolar->Click += gcnew System::EventHandler(this, &Form1::btnEncolar_Click);
			// 
			// btnDesencolar
			// 
			this->btnDesencolar->Location = System::Drawing::Point(169, 63);
			this->btnDesencolar->Name = L"btnDesencolar";
			this->btnDesencolar->Size = System::Drawing::Size(75, 23);
			this->btnDesencolar->TabIndex = 3;
			this->btnDesencolar->Text = L"Desencolar";
			this->btnDesencolar->UseVisualStyleBackColor = true;
			this->btnDesencolar->Click += gcnew System::EventHandler(this, &Form1::btnDesencolar_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(21, 63);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(142, 150);
			this->Grid->TabIndex = 4;
			this->Grid->RowCount = 50;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Cola";
			this->Column1->Name = L"Column1";
			// 
			// btnElimPar
			// 
			this->btnElimPar->Location = System::Drawing::Point(187, 126);
			this->btnElimPar->Name = L"btnElimPar";
			this->btnElimPar->Size = System::Drawing::Size(75, 49);
			this->btnElimPar->TabIndex = 5;
			this->btnElimPar->Text = L"Eliminar Pares";
			this->btnElimPar->UseVisualStyleBackColor = true;
			this->btnElimPar->Click += gcnew System::EventHandler(this, &Form1::btnElimPar_Click);
			// 
			// Grilla2
			// 
			this->Grilla2->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn1});
			this->Grilla2->Location = System::Drawing::Point(292, 63);
			this->Grilla2->Name = L"Grilla2";
			this->Grilla2->Size = System::Drawing::Size(142, 150);
			this->Grilla2->TabIndex = 6;
			this->Grilla2->RowCount = 50;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Cola";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(478, 261);
			this->Controls->Add(this->Grilla2);
			this->Controls->Add(this->btnElimPar);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnDesencolar);
			this->Controls->Add(this->btnEncolar);
			this->Controls->Add(this->txtDato);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnEncolar_Click(System::Object^  sender, System::EventArgs^  e) {
				 if(C1.lleno()==true)
					 MessageBox::Show("La cola esta llena");
				 else{
				 int elem=Convert::ToInt32(txtDato->Text);
				 C1.encolar(elem);
				 Grid->Rows[pos++]->Cells[0]->Value=elem;}
			 }
private: System::Void btnDesencolar_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(C1.vacio()==true)
				 MessageBox::Show("La cola esta vacia");
			 else{
			 C1.desencolar();
			 Grid->Rows->RemoveAt(fren++);}
		 }
private: System::Void btnElimPar_Click(System::Object^  sender, System::EventArgs^  e) {
				
			 do
				{
					int elem=C1.desencolar();
					if(elem%2!=0)
						{C2.encolar(elem);
					Grilla2->Rows[pos2++]->Cells[0]->Value=elem;
					}
				}while (C1.vacio()==false);
		 }
};
}

