#pragma once
#define M 50
class Cola
{
private:
	int frente;
	int final;
	int C[M];

public:
	Cola(void);
	void encolar(int x);
	int desencolar();
	bool lleno();
	bool vacio();
	Cola ElimPares(Cola C1);
};

