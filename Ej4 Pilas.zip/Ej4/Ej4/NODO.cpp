#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
}
