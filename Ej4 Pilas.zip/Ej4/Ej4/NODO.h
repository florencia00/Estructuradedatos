#pragma once
class NODO
{
protected:
	int elemento;
public:
	NODO(void);
};

